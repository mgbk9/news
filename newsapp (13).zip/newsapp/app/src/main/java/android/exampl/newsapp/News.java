package android.exampl.newsapp;

public class News {
    private String mtitle;
    private String msectionId;
    private String mdate;
    private String mUrl;

    public News(String title, String sectionId, String date, String url) {
        mtitle = title;
        msectionId = sectionId;
        mdate = date;
        mUrl = url;

    }

    public String getmtitle() {
        return mtitle;
    }

    public String getmsectionId() {
        return msectionId;
    }


    public String getMdate() {
        return mdate;
    }

    public String getUrl() {
        return mUrl;
    }


}
