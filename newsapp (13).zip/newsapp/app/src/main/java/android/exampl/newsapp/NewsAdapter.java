package android.exampl.newsapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class NewsAdapter extends ArrayAdapter<News> {
    public NewsAdapter(Activity context, ArrayList<News> n) {

        super(context, 0, n);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.news_list, parent, false);
        }
        News currentnews = getItem(position);
        TextView title = (TextView) listItemView.findViewById(R.id.title_show);
        title.setText(currentnews.getmtitle());
        TextView type = (TextView) listItemView.findViewById(R.id.id);
        type.setText(currentnews.getmsectionId());
        TextView date = (TextView) listItemView.findViewById(R.id.date);
        date.setText(currentnews.getMdate());
        return listItemView;
    }
}
