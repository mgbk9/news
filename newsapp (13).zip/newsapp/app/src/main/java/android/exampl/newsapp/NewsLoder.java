package android.exampl.newsapp;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

public class NewsLoder extends AsyncTaskLoader<List<News>> {


    private String mUrl;

    public NewsLoder(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }


    @Override
    public List<News> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        List<News> newsList = android.exampl.newsapp.Queryutils.fetche(mUrl);
        return newsList;
    }
}