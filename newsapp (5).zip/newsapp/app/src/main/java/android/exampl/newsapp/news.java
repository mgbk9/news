package android.exampl.newsapp;

public class news {
    private String mtype;
    private String mtitl;
    private String mUrl;
    private String msectionName;

    public news(String art, String location, String url, String sectionName) {
        mtype = art;
        mtitl = location;
        mUrl = url;
        msectionName = sectionName;
    }

    public String getart() {
        return mtype;
    }

    public String getmtitle() {
        return mtitl;
    }


    public String getUrl() {
        return mUrl;
    }

    public String getMsectionName() {
        return msectionName;
    }
}
