package android.exampl.newsapp;

public class news {
    private String mtype;
    private String mtitle;
    private String mUrl;
    private String msectionName;

    public news(String type, String title, String url, String sectionName) {
        mtype = type;
        mtitle = title;
        mUrl = url;
        msectionName = sectionName;
    }

    public String gettype() {
        return mtype;
    }

    public String getmtitle() {
        return mtitle;
    }


    public String getUrl() {
        return mUrl;
    }

    public String getMsectionName() {
        return msectionName;
    }
}
