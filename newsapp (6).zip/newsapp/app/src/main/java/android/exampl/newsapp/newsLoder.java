package android.exampl.newsapp;

import android.content.AsyncTaskLoader;
import android.content.Context;

import java.util.List;

public class newsLoder extends AsyncTaskLoader<List<news>> {


    private String mUrl;

    public newsLoder(Context context, String url) {
        super(context);
        mUrl = url;
    }

    @Override
    protected void onStartLoading() {
        forceLoad();
    }


    @Override
    public List<news> loadInBackground() {
        if (mUrl == null) {
            return null;
        }

        List<news> newsss = android.exampl.newsapp.queryutils.fetcheData(mUrl);
        return newsss;
    }
}