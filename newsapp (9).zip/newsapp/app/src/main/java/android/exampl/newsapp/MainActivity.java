package android.exampl.newsapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Loader;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity
        implements LoaderCallbacks<List<news>> {
    private static final String LOG_TAG = MainActivity.class.getName();
    private static final String REQUEST_URL =
            "https://content.guardianapis.com/search?q=debate&tag=politics/politics&from-date=2014-01-01&api-key=test";

    private static final int LOADER_ID = 1;
    private newsAdapter mAdapter;
    private TextView mEmptyStateTextView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ListView listView = (ListView) findViewById(R.id.list);
        mAdapter = new newsAdapter(this, new ArrayList<news>());
        listView.setAdapter(mAdapter);
        mEmptyStateTextView = (TextView) findViewById(R.id.empty_view);
        listView.setEmptyView(mEmptyStateTextView);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                news currentE = mAdapter.getItem(position);

                Uri newsUri = Uri.parse("https://www.theguardian.com/us-news/2020/sep/30/presidential-debates-format-overhauled-trump-biden");

                Intent websiteIntent = new Intent(Intent.ACTION_VIEW, newsUri);
                startActivity(websiteIntent);
            }
        });
        LoaderManager loaderManager = getLoaderManager();
        loaderManager.initLoader(LOADER_ID, null, this);
    }
    @Override
    public Loader<List<news>> onCreateLoader(int i, Bundle bundle) {

        return new newsLoder(this, REQUEST_URL);



    }
    @Override
    public void onLoadFinished(Loader<List<news>> loader, List<news> ne) {
        View loadingIndicator = findViewById(R.id.loading_indicator);
        loadingIndicator.setVisibility(View.GONE);
        mEmptyStateTextView.setText(R.string.no_news);
        mAdapter.clear();
        if (ne != null && !ne.isEmpty()) {
            mAdapter.addAll(ne);
            mEmptyStateTextView.setText(R.string.no_news);

        }
    }

    @Override
    public void onLoaderReset(Loader<List<news>> loader) {
        mAdapter.clear();
    }
}