package android.exampl.newsapp;

public class news {
    private String mtitle;
    private String msectionId;
    private String msectionName;
    private long mDate;
    private String mUrl;
    public news( String title,String sectionName,String sectionId,long Date, String url) {
        mtitle = title;
        msectionName = sectionName;
        msectionName = sectionId;
        mDate = Date;
        mUrl = url;

    }
    public String getmtitle() {
        return mtitle;
    }
    public String getMsectionName() {
        return msectionName;
    }
    public String getmsectionId() {
        return msectionId;
    }
    public long getmDate(){return mDate;}
    public String getUrl() {
        return mUrl;
    }


}
